高速廻転寿司 (Windows版) 説明書

* これは何?
寿司が高速で走るレースゲームです。

* 遊び方
** 起動方法
KousokuKaitenzushi.exeをダブルクリックしてください。
画質とウィンドウのサイズが選べるダイアログが出るので、好みのものを選んで「Play!」を押してください。
(注意: 同梱のKousokuKaitenzushi_Dataは必ずKousokuKaitenzushi.exeと同じフォルダに置いて起動してください。)

** 操作方法
*** 一般
- カーソル移動: ↑↓→← または WASD またはHJKL
- 決定: Space または Enter
- 前の画面に戻る: Esc
- 消音/消音解除: M

*** 寿司の操作
- 加速: Space または Enter
- 右旋回: → または D または L
- 左旋回: ← または A または H

* 作者
ye_ey (Twitter: @ye_ey)

* クレジット
** BGM, SE
- 魔王魂: http://maoudamashii.jokersounds.com/

** Unity Assets
- Japanese Sushi (ANGEWORK.co.ltd): https://www.assetstore.unity3d.com/jp/#!/content/37401
- Skybox Purple Nebula (Unluck Software): https://www.assetstore.unity3d.com/jp/#!/content/2967
- Toony Skies (Arkham Interactive): https://www.assetstore.unity3d.com/jp/#!/content/11020
- Free Furniture Pack 1 (Ka Design): https://www.assetstore.unity3d.com/jp/#!/content/11859
- Animated Horse (Dootsy Development): https://www.assetstore.unity3d.com/jp/#!/content/16687
- Japanese Otaku City (ZENRIN CO., LTD.): https://www.assetstore.unity3d.com/jp/#!/content/20359

** ゲームエンジン
- Unity (Unity Technologies): http://unity3d.com/

** ゲームデザイン, プログラム
- ye_ey: https://twitter.com/ye_ey
